/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: mysql    Database: natural_products
-- ------------------------------------------------------
-- Server version	8.4.9

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias_ingrediente`
--

DROP TABLE IF EXISTS `categorias_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias_ingrediente` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `categorias_ingrediente_nombre_key` (`nombre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias_ingrediente`
--

LOCK TABLES `categorias_ingrediente` WRITE;
/*!40000 ALTER TABLE `categorias_ingrediente` DISABLE KEYS */;
INSERT INTO `categorias_ingrediente` VALUES
(1,'frutas',1,'2026-05-24 22:10:28.489'),
(2,'verduras',1,'2026-05-24 22:10:28.499'),
(3,'condimentos',1,'2026-05-24 22:10:28.506'),
(4,'aceites',1,'2026-05-24 22:10:28.514'),
(5,'proteinas',1,'2026-05-24 22:10:28.523'),
(6,'granos',1,'2026-05-24 22:10:28.532');
/*!40000 ALTER TABLE `categorias_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `gastos`
--

DROP TABLE IF EXISTS `gastos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `gastos` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `producto_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `valor` decimal(14,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `fecha_gasto` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `actualizado_en` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gastos_producto_id_fkey` (`producto_id`),
  CONSTRAINT `gastos_producto_id_fkey` FOREIGN KEY (`producto_id`) REFERENCES `productos_finales` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gastos`
--

LOCK TABLES `gastos` WRITE;
/*!40000 ALTER TABLE `gastos` DISABLE KEYS */;
/*!40000 ALTER TABLE `gastos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ingredientes`
--

DROP TABLE IF EXISTS `ingredientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ingredientes` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categoria_id` int DEFAULT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `actualizado_en` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ingredientes_nombre_key` (`nombre`),
  KEY `ingredientes_categoria_id_fkey` (`categoria_id`),
  CONSTRAINT `ingredientes_categoria_id_fkey` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_ingrediente` (`id`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ingredientes`
--

LOCK TABLES `ingredientes` WRITE;
/*!40000 ALTER TABLE `ingredientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `ingredientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `producto_recipiente`
--

DROP TABLE IF EXISTS `producto_recipiente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `producto_recipiente` (
  `producto_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `recipiente_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad_unidades` int NOT NULL DEFAULT '0',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`producto_id`,`recipiente_id`),
  KEY `producto_recipiente_recipiente_id_fkey` (`recipiente_id`),
  CONSTRAINT `producto_recipiente_producto_id_fkey` FOREIGN KEY (`producto_id`) REFERENCES `productos_finales` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `producto_recipiente_recipiente_id_fkey` FOREIGN KEY (`recipiente_id`) REFERENCES `tipos_recipientes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `producto_recipiente`
--

LOCK TABLES `producto_recipiente` WRITE;
/*!40000 ALTER TABLE `producto_recipiente` DISABLE KEYS */;
/*!40000 ALTER TABLE `producto_recipiente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos_finales`
--

DROP TABLE IF EXISTS `productos_finales`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos_finales` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `descripcion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `imagen_url` text COLLATE utf8mb4_unicode_ci,
  `cantidad_ml` decimal(10,2) NOT NULL,
  `porcentaje_ganancia` decimal(5,2) NOT NULL,
  `porcentaje_perdida` decimal(5,2) NOT NULL DEFAULT '0.00',
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `actualizado_en` datetime(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos_finales`
--

LOCK TABLES `productos_finales` WRITE;
/*!40000 ALTER TABLE `productos_finales` DISABLE KEYS */;
/*!40000 ALTER TABLE `productos_finales` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `recetas_producto_ingrediente`
--

DROP TABLE IF EXISTS `recetas_producto_ingrediente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `recetas_producto_ingrediente` (
  `producto_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ingrediente_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cantidad_ml` decimal(10,2) NOT NULL,
  `precio_por_ml` decimal(12,4) NOT NULL,
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`producto_id`,`ingrediente_id`),
  KEY `recetas_producto_ingrediente_ingrediente_id_fkey` (`ingrediente_id`),
  CONSTRAINT `recetas_producto_ingrediente_ingrediente_id_fkey` FOREIGN KEY (`ingrediente_id`) REFERENCES `ingredientes` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `recetas_producto_ingrediente_producto_id_fkey` FOREIGN KEY (`producto_id`) REFERENCES `productos_finales` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `recetas_producto_ingrediente`
--

LOCK TABLES `recetas_producto_ingrediente` WRITE;
/*!40000 ALTER TABLE `recetas_producto_ingrediente` DISABLE KEYS */;
/*!40000 ALTER TABLE `recetas_producto_ingrediente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipos_recipientes`
--

DROP TABLE IF EXISTS `tipos_recipientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tipos_recipientes` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `valor` decimal(14,2) NOT NULL,
  `tamano_recipiente` decimal(14,2) NOT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `tipos_recipientes_nombre_key` (`nombre`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipos_recipientes`
--

LOCK TABLES `tipos_recipientes` WRITE;
/*!40000 ALTER TABLE `tipos_recipientes` DISABLE KEYS */;
/*!40000 ALTER TABLE `tipos_recipientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nombre` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apellidos` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identificacion` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `correo` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `telefono` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_recuperacion` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `expira_recuperacion` datetime(3) DEFAULT NULL,
  `activo` tinyint(1) NOT NULL DEFAULT '1',
  `creado_en` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `actualizado_en` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuarios_identificacion_key` (`identificacion`),
  UNIQUE KEY `usuarios_correo_key` (`correo`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES
('26c187ac-1175-45c5-8f0b-b896781b46a4','Administrador','Sistema','0000000000','admin@alnatural.com',NULL,'$2b$10$LajWxuSJZfNrA0Fkagph0OeNuIGpyXVzuO0PFIJLLLnQcRJx2yTSK',NULL,NULL,1,'2026-05-24 22:10:28.592','2026-05-24 22:10:28.592');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-24 22:19:58
